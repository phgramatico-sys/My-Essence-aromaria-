// Conexão com o banco Neon (PostgreSQL).
// Sem DATABASE_URL, o site continua funcionando com public/catalog.json.
const fs = require('fs');
const path = require('path');

const URL = process.env.DATABASE_URL || '';
let pool = null;
if (URL) {
  const { Pool } = require('pg');
  pool = new Pool({ connectionString: URL, ssl: { rejectUnauthorized: true }, max: 3, idleTimeoutMillis: 10000 });
  pool.on('error', e => console.error('Neon:', e.message));
}
const ativo = () => !!pool;
const q = (text, params) => pool.query(text, params).then(r => r.rows);

// ---------- catálogo (mesmo formato do catalog.json) ----------
let cache = null, cacheAt = 0;
const TTL = 60 * 1000; // alterações feitas na Neon aparecem no site em até 1 minuto

function fromFile() {
  return JSON.parse(fs.readFileSync(path.join(__dirname, 'public', 'catalog.json'), 'utf8'));
}

async function getCatalog() {
  if (!pool) return fromFile();
  if (cache && Date.now() - cacheAt < TTL) return cache;
  try {
    const [cfg, fams, prods, refs] = await Promise.all([
      q('SELECT chave, valor FROM loja_config'),
      q('SELECT slug, nome, cor, fundo, escura FROM familias ORDER BY ordem, nome'),
      q(`SELECT id, nome, categoria, genero, tipo, familia, intensidade, ocasioes, preco, volume, descricao,
                img, foco, destaque, estoque, detalhes
           FROM produtos WHERE ativo ORDER BY ordem, nome`),
      q('SELECT nome, produto_id FROM referencias')
    ]);
    const C = Object.fromEntries(cfg.map(r => [r.chave, r.valor]));
    const data = {
      loja: C.loja || {},
      familias: Object.fromEntries(fams.map(f => [f.slug, { nome: f.nome, cor: f.cor, fundo: f.fundo, escura: f.escura }])),
      ocasioes: C.ocasioes || {},
      categorias: C.categorias || {},
      produtos: prods.map(p => {
        const o = {
          ...(p.detalhes || {}),
          id: p.id, nome: p.nome, cat: p.categoria, tipo: p.tipo, familia: p.familia,
          intensidade: p.intensidade, ocasioes: p.ocasioes || [], preco: Number(p.preco),
          volume: p.volume, descricao: p.descricao
        };
        if (p.genero) o.genero = p.genero;
        if (p.img) o.img = p.img;
        if (p.foco) o.foco = p.foco;
        if (p.destaque) o.destaque = true;
        if (p.estoque === 0) o.esgotado = true;
        return o;
      }),
      referencias: Object.fromEntries(refs.map(r => [r.nome, r.produto_id]))
    };
    cache = data; cacheAt = Date.now();
    return data;
  } catch (e) {
    console.error('Neon catálogo:', e.message);
    return cache || fromFile(); // se o banco cair, o site não sai do ar
  }
}

// ---------- pedidos ----------
async function salvarPedido({ codigo, itens, presente, mensagem }) {
  const ids = itens.map(i => i.id);
  const prods = await q('SELECT id, nome, preco FROM produtos WHERE id = ANY(string_to_array($1, \',\')) AND ativo', [ids.join(',')]);
  const byId = Object.fromEntries(prods.map(p => [p.id, p]));
  const linhas = itens.filter(i => byId[i.id]).map(i => ({ ...byId[i.id], qtd: i.qtd }));
  if (!linhas.length) throw new Error('pedido sem itens válidos');
  const subtotal = linhas.reduce((s, l) => s + Number(l.preco) * l.qtd, 0);
  const cat = await getCatalog();
  const regua = (cat.loja.reguaAmostras || []).filter(r => subtotal >= r.valor).pop();

  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const r = await client.query(
      `INSERT INTO pedidos (codigo, subtotal, brinde, presente, mensagem_presente)
       VALUES ($1, $2, $3, $4, $5) ON CONFLICT (codigo) DO NOTHING RETURNING id`,
      [codigo, subtotal.toFixed(2), regua ? regua.brinde : null, !!presente, presente ? (mensagem || null) : null]);
    if (!r.rows.length) { await client.query('ROLLBACK'); return { codigo, duplicado: true }; }
    const pid = r.rows[0].id;
    for (const l of linhas) {
      await client.query(
        'INSERT INTO pedido_itens (pedido_id, produto_id, nome, preco_unit, quantidade) VALUES ($1, $2, $3, $4, $5)',
        [pid, l.id, l.nome, l.preco, l.qtd]);
    }
    await client.query('COMMIT');
    return { codigo, subtotal };
  } catch (e) {
    await client.query('ROLLBACK').catch(() => {});
    throw e;
  } finally {
    client.release();
  }
}

// ---------- avaliações ----------
async function listarAvaliacoes(produtoId) {
  const rows = await q(
    `SELECT nome, nota, fixacao, fiel_descricao, uso, comentario, criado_em
       FROM avaliacoes WHERE produto_id = $1 AND aprovada ORDER BY criado_em DESC LIMIT 20`, [produtoId]);
  return rows;
}

async function salvarAvaliacao(a) {
  await q(
    `INSERT INTO avaliacoes (produto_id, nome, nota, fixacao, fiel_descricao, uso, comentario)
     SELECT $1, $2, $3, $4, $5, $6, $7 WHERE EXISTS (SELECT 1 FROM produtos WHERE id = $1)`,
    [a.produto, a.nome, a.nota, a.fixacao, a.fiel, a.uso, a.comentario]);
}

module.exports = { ativo, getCatalog, salvarPedido, listarAvaliacoes, salvarAvaliacao };
