# MyEssence Aromas — como publicar na Hostinger

## O que tem aqui
- `public/index.html` — o site completo (catálogo, vídeos em destaque, quiz, "se você gosta de…", camadas, sacola com pedido pelo WhatsApp).
- `public/catalog.json` — **todos os produtos, preços, notas e políticas**. Para mudar o catálogo, edite só este arquivo.
- `public/assets/` — logo e fotos. Para trocar a foto de um produto, coloque a imagem aqui e preencha `"img"` no catálogo.
- `server.js` — servidor Node.js que entrega o site, responde o chat com a IA do Claude e salva pedidos/avaliações.
- `db.js` — conexão com o banco Neon.
- `banco/neon-banco.sql` — cria as tabelas na Neon e já cadastra todo o catálogo.

## Banco de dados (Neon)
1. Em neon.tech, crie um projeto (região mais próxima disponível) e abra o **SQL Editor**.
2. Cole todo o conteúdo de `banco/neon-banco.sql` e clique em **Run**. Rode só uma vez: rodar de novo apaga pedidos e avaliações.
3. Em **Connect**, copie a *connection string* (opção **Pooled connection**).
4. Na Hostinger, crie a variável `DATABASE_URL` com essa string e reimplante o app.

Com o banco ligado:
- O catálogo passa a vir da tabela `produtos` (mudanças aparecem no site em até 1 minuto). `estoque = 0` mostra "Esgotado"; `ativo = false` tira do site.
- Cada pedido finalizado no WhatsApp é salvo com um código (ex: `ME-7K2Q9A`) que aparece na mensagem. Veja em `SELECT * FROM vw_pedidos;`.
- Avaliações enviadas pelo site ficam em `avaliacoes` e só aparecem depois de `aprovada = true`.
- O final de `neon-banco.sql` tem consultas prontas (mudar preço, aprovar avaliação, criar cupom de cashback).

Sem `DATABASE_URL`, o site continua funcionando com `public/catalog.json`.

## Publicar (plano Business/Unlimited)
1. Suba esta pasta para um repositório no GitHub (ou envie o .zip).
2. No hPanel: **Sites → Adicionar site → Node.js Web App** → escolha o repositório ou o .zip.
3. Framework: **Other / Express**. Comando de início: `npm start`. Node 20 ou superior.
4. Em **Variáveis de ambiente**, crie `ANTHROPIC_API_KEY` (chave de console.anthropic.com) e `DATABASE_URL` (Neon).
5. Conecte o domínio do Registro.br: no Registro.br, troque os servidores DNS para os da Hostinger.

## Antes de divulgar, revise
- Preços, fixação, durabilidade e produtos são **exemplos**: troque pelos reais (no `catalog.json` antes de gerar o banco, ou direto na tabela `produtos` da Neon).
- `cnpj` e o texto da ANVISA em `catalog.json` (`loja`).
- Valores da régua de amostras grátis (`reguaAmostras`).
- Defina um limite de gastos mensal da API no console da Anthropic.
