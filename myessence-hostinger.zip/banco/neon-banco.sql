-- =====================================================================
--  MyEssence Aromas — banco de dados (Neon / PostgreSQL)
--  Como usar: no painel da Neon, abra o "SQL Editor", cole este arquivo
--  inteiro e clique em "Run". Ele cria as tabelas e já cadastra o catálogo.
--  Pode rodar de novo sem medo: ele apaga e recria tudo (CUIDADO: apaga
--  pedidos e avaliações também — use só na primeira vez ou em testes).
-- =====================================================================

DROP VIEW  IF EXISTS vw_mais_vendidos, vw_pedidos;
DROP TABLE IF EXISTS cupons, avaliacoes, pedido_itens, pedidos, referencias, produtos, familias, loja_config CASCADE;

-- Configurações gerais da loja (WhatsApp, Instagram, régua de amostras, CNPJ...)
CREATE TABLE loja_config (
  chave  text PRIMARY KEY,
  valor  jsonb NOT NULL
);

-- Famílias olfativas e as cores que o site usa para cada uma
CREATE TABLE familias (
  slug    text PRIMARY KEY,
  nome    text NOT NULL,
  cor     text NOT NULL,
  fundo   text NOT NULL,
  escura  text NOT NULL,
  ordem   int  NOT NULL DEFAULT 0
);

-- Produtos. As colunas principais são fáceis de editar direto na Neon;
-- os detalhes olfativos (notas, acordes, fixação, instruções) ficam em "detalhes".
CREATE TABLE produtos (
  id             text PRIMARY KEY,                      -- ex: 'million' (sem espaço)
  nome           text NOT NULL,
  categoria      text NOT NULL CHECK (categoria IN ('corporal','casa','automotivo','kits')),
  genero         text CHECK (genero IN ('masculino','feminino','unissex')),
  tipo           text NOT NULL,                         -- ex: 'Perfume (EDP)', 'Difusor de Varetas'
  familia        text NOT NULL REFERENCES familias(slug),
  intensidade    text NOT NULL CHECK (intensidade IN ('Suave','Moderada','Intensa')),
  ocasioes       text[] NOT NULL DEFAULT '{}',          -- dia, noite, verao, inverno, relax
  preco          numeric(10,2) NOT NULL CHECK (preco >= 0),
  volume         text,
  descricao      text,
  img            text,                                  -- ex: 'assets/masc.jpg' (vazio = ilustração)
  foco           text,                                  -- enquadramento da foto, ex: '22% 50%'
  destaque       boolean NOT NULL DEFAULT false,        -- aparece nos vídeos em destaque (até 5)
  ativo          boolean NOT NULL DEFAULT true,         -- false = some do site
  estoque        int CHECK (estoque IS NULL OR estoque >= 0), -- NULL = não controlar; 0 = esgotado
  ordem          int NOT NULL DEFAULT 0,
  detalhes       jsonb NOT NULL DEFAULT '{}'::jsonb,
  criado_em      timestamptz NOT NULL DEFAULT now(),
  atualizado_em  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX produtos_categoria_idx ON produtos (categoria) WHERE ativo;

CREATE OR REPLACE FUNCTION toca_atualizado_em() RETURNS trigger AS $$
BEGIN NEW.atualizado_em := now(); RETURN NEW; END $$ LANGUAGE plpgsql;
CREATE TRIGGER produtos_atualizado BEFORE UPDATE ON produtos
  FOR EACH ROW EXECUTE FUNCTION toca_atualizado_em();

-- "Se você gosta de X": perfume famoso -> produto da loja
CREATE TABLE referencias (
  nome        text PRIMARY KEY,
  produto_id  text NOT NULL REFERENCES produtos(id) ON DELETE CASCADE
);

-- Pedidos enviados pelo site (o cliente finaliza no WhatsApp com o mesmo código)
CREATE TABLE pedidos (
  id                 bigserial PRIMARY KEY,
  codigo             text NOT NULL UNIQUE,              -- ex: ME-7K2Q9A (aparece na mensagem do WhatsApp)
  subtotal           numeric(10,2) NOT NULL,
  brinde             text,
  presente           boolean NOT NULL DEFAULT false,
  mensagem_presente  text,
  status             text NOT NULL DEFAULT 'aguardando_whatsapp'
                     CHECK (status IN ('aguardando_whatsapp','confirmado','pago','enviado','entregue','cancelado')),
  observacoes        text,
  criado_em          timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX pedidos_criado_idx ON pedidos (criado_em DESC);

CREATE TABLE pedido_itens (
  id          bigserial PRIMARY KEY,
  pedido_id   bigint NOT NULL REFERENCES pedidos(id) ON DELETE CASCADE,
  produto_id  text REFERENCES produtos(id) ON DELETE SET NULL,
  nome        text NOT NULL,                            -- guardado para o histórico não mudar
  preco_unit  numeric(10,2) NOT NULL,
  quantidade  int NOT NULL CHECK (quantidade > 0)
);
CREATE INDEX pedido_itens_pedido_idx ON pedido_itens (pedido_id);

-- Avaliações dos clientes (só aparecem no site depois de aprovada = true)
CREATE TABLE avaliacoes (
  id              bigserial PRIMARY KEY,
  produto_id      text NOT NULL REFERENCES produtos(id) ON DELETE CASCADE,
  nome            text NOT NULL,
  nota            smallint NOT NULL CHECK (nota BETWEEN 1 AND 5),
  fixacao         text CHECK (fixacao IN ('Fraca','Boa','Excelente')),
  fiel_descricao  boolean,
  uso             text,                                 -- ambiente/ocasião onde usou
  comentario      text,
  aprovada        boolean NOT NULL DEFAULT false,
  criado_em       timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX avaliacoes_produto_idx ON avaliacoes (produto_id) WHERE aprovada;

-- Cupons de cashback (ex: valor do kit de amostras para usar no frasco de 100 ml)
CREATE TABLE cupons (
  codigo         text PRIMARY KEY,
  tipo           text NOT NULL DEFAULT 'cashback_kit',
  valor          numeric(10,2) NOT NULL CHECK (valor > 0),
  pedido_codigo  text REFERENCES pedidos(codigo) ON DELETE SET NULL,
  cliente        text,
  usado          boolean NOT NULL DEFAULT false,
  valido_ate     date,
  criado_em      timestamptz NOT NULL DEFAULT now()
);

-- Relatórios prontos
CREATE VIEW vw_pedidos AS
SELECT p.codigo, p.criado_em, p.status, p.subtotal, p.presente, p.brinde,
       string_agg(i.quantidade || 'x ' || i.nome, ', ' ORDER BY i.id) AS itens
FROM pedidos p LEFT JOIN pedido_itens i ON i.pedido_id = p.id
GROUP BY p.id ORDER BY p.criado_em DESC;

CREATE VIEW vw_mais_vendidos AS
SELECT i.produto_id, max(i.nome) AS nome, sum(i.quantidade) AS unidades,
       sum(i.quantidade * i.preco_unit) AS faturamento
FROM pedido_itens i JOIN pedidos p ON p.id = i.pedido_id
WHERE p.status <> 'cancelado'
GROUP BY i.produto_id ORDER BY unidades DESC;

-- ===================== CARGA INICIAL =====================

BEGIN;

INSERT INTO loja_config (chave, valor) VALUES
  ('loja', '{"nome":"MyEssence Aromas","whatsapp":"5511963914995","whatsappTexto":"(11) 96391-4995","instagram":"my.essence_aromaria","freteObs":"Frete e prazo calculados pelo WhatsApp conforme o CEP.","reguaAmostras":[{"valor":150,"brinde":"1 flaconete à sua escolha"},{"valor":250,"brinde":"2 flaconetes + 1 mini aromatizador automotivo"}],"cnpj":"00.000.000/0000-00","anvisa":"Produtos cosméticos notificados/registrados na ANVISA conforme o grau de risco (Grau 1 ou 2)."}'::jsonb),
  ('ocasioes', '{"dia":"Dia a dia / Trabalho","noite":"Encontros / Noite","verao":"Dias quentes / Verão","inverno":"Dias frios / Inverno","relax":"Pós-banho / Relaxamento"}'::jsonb),
  ('categorias', '{"masculino":"Masculinos","feminino":"Femininos","corporal":"Corporal","casa":"Casa & Ambientes","automotivo":"Automotivo","kits":"Kits & Presentes"}'::jsonb);

INSERT INTO familias (slug, nome, cor, fundo, escura, ordem) VALUES
  ('citrico', 'Cítrico', '#d9a92b', '#fff6dc', '#7a5b0c', 0),
  ('floral', 'Floral', '#c46a8a', '#fbe9ef', '#7d2f4b', 1),
  ('amadeirado', 'Amadeirado', '#6f7f4f', '#eaeee0', '#3d4728', 2),
  ('oriental', 'Oriental / Âmbar', '#c4862b', '#f8e8c9', '#6e4512', 3),
  ('aromatico', 'Aromático / Fresco', '#5f9c8a', '#e2f1ec', '#2c5a4c', 4),
  ('gourmand', 'Gourmand (Doce)', '#a86f45', '#f4e3d3', '#5e3519', 5),
  ('frutado', 'Frutado', '#d9694f', '#fbe2da', '#83321f', 6),
  ('chipre', 'Chipre', '#4f6d5a', '#e3ebe5', '#24382b', 7);

INSERT INTO produtos (id, nome, categoria, genero, tipo, familia, intensidade, ocasioes, preco, volume, descricao, img, foco, destaque, ordem, detalhes) VALUES
  ('million', 'Inspiração Million', 'corporal', 'masculino', 'Perfume (EDP)', 'oriental', 'Intensa', ARRAY['noite','inverno']::text[], 129.9, '100 ml', 'Especiado, doce e com couro marcante. Feito para a noite e para quem gosta de ser notado.', 'assets/masc.jpg', '22% 50%', true, 0, '{"ref":["Million","1 Million","One Million"],"notas":{"topo":["Toranja","Menta","Tangerina"],"coracao":["Rosa","Canela"],"fundo":["Couro","Âmbar","Madeiras"]},"acordes":[["Especiado quente",100],["Doce",80],["Couro",65],["Cítrico",50],["Amadeirado",45]],"fixacao":[5,"Alta — 8h a 10h"],"projecao":[4,"Forte — deixa rastro marcante"],"concentracao":"20% de essência (Eau de Parfum)","rendimento":"aprox. 1.000 borrifadas","camada":"bs-baunilha"}'::jsonb),
  ('sauvage', 'Inspiração Sauvage', 'corporal', 'masculino', 'Perfume (EDP)', 'aromatico', 'Moderada', ARRAY['dia','verao','noite']::text[], 119.9, '100 ml', 'Fresco e magnético, com bergamota vibrante e fundo amadeirado. Versátil para o dia a dia.', NULL, NULL, false, 1, '{"ref":["Sauvage"],"notas":{"topo":["Bergamota","Pimenta"],"coracao":["Lavanda","Gerânio"],"fundo":["Ambroxan","Cedro"]},"acordes":[["Aromático",100],["Cítrico",75],["Fresco especiado",70],["Amadeirado",50]],"fixacao":[4,"Alta — 7h a 9h"],"projecao":[4,"Forte — aura presente"],"concentracao":"20% de essência (Eau de Parfum)","rendimento":"aprox. 1.000 borrifadas"}'::jsonb),
  ('bleu', 'Inspiração Bleu', 'corporal', 'masculino', 'Perfume (EDP)', 'amadeirado', 'Moderada', ARRAY['dia','noite']::text[], 119.9, '100 ml', 'Amadeirado elegante com frescor cítrico. Funciona do escritório ao jantar.', NULL, NULL, false, 2, '{"ref":["Bleu","Bleu de Chanel"],"notas":{"topo":["Limão Siciliano","Menta"],"coracao":["Gengibre","Noz-moscada"],"fundo":["Sândalo","Cedro","Incenso"]},"acordes":[["Amadeirado",100],["Cítrico",70],["Aromático",60],["Incenso",40]],"fixacao":[4,"Alta — 7h a 9h"],"projecao":[3,"Moderada — elegante sem sufocar"],"concentracao":"20% de essência (Eau de Parfum)","rendimento":"aprox. 1.000 borrifadas"}'::jsonb),
  ('invictus', 'Inspiração Invictus', 'corporal', 'masculino', 'Perfume (EDP)', 'aromatico', 'Moderada', ARRAY['dia','verao']::text[], 109.9, '100 ml', 'Esportivo, salgado e cítrico. Perfeito para dias quentes.', NULL, NULL, false, 3, '{"ref":["Invictus"],"notas":{"topo":["Toranja","Notas Marinhas"],"coracao":["Louro","Jasmim"],"fundo":["Musgo","Âmbar Gris","Guaiaco"]},"acordes":[["Fresco marinho",100],["Cítrico",80],["Amadeirado",55],["Aromático",45]],"fixacao":[3,"Moderada — 6h a 8h"],"projecao":[3,"Moderada"],"concentracao":"20% de essência (Eau de Parfum)","rendimento":"aprox. 1.000 borrifadas"}'::jsonb),
  ('lady-million', 'Inspiração Lady Million', 'corporal', 'feminino', 'Perfume (EDP)', 'floral', 'Intensa', ARRAY['noite','inverno']::text[], 129.9, '100 ml', 'Floral dourado com mel e frutas vermelhas. Glamour para noites especiais.', 'assets/fem.jpg', '28% 55%', true, 4, '{"ref":["Lady Million"],"notas":{"topo":["Framboesa","Neroli","Limão"],"coracao":["Jasmim","Gardênia","Flor de Laranjeira"],"fundo":["Mel","Patchouli","Âmbar"]},"acordes":[["Floral branco",100],["Doce / Mel",85],["Frutado",60],["Patchouli",50]],"fixacao":[5,"Alta — 8h a 10h"],"projecao":[4,"Forte — rastro luminoso"],"concentracao":"20% de essência (Eau de Parfum)","rendimento":"aprox. 1.000 borrifadas","camada":"oleo-laranjeira"}'::jsonb),
  ('mademoiselle', 'Inspiração Mademoiselle', 'corporal', 'feminino', 'Perfume (EDP)', 'chipre', 'Moderada', ARRAY['dia','noite']::text[], 129.9, '100 ml', 'Clássico moderno: cítrico, rosa e patchouli. Elegância do dia à noite.', 'assets/fem.jpg', '72% 55%', true, 5, '{"ref":["Coco Mademoiselle","Mademoiselle"],"notas":{"topo":["Laranja","Bergamota"],"coracao":["Rosa","Jasmim"],"fundo":["Patchouli","Vetiver","Baunilha"]},"acordes":[["Chipre",100],["Cítrico",70],["Floral rosado",65],["Patchouli",60]],"fixacao":[4,"Alta — 7h a 9h"],"projecao":[3,"Moderada — sofisticado"],"concentracao":"20% de essência (Eau de Parfum)","rendimento":"aprox. 1.000 borrifadas","camada":"bs-baunilha"}'::jsonb),
  ('good-girl', 'Inspiração Good Girl', 'corporal', 'feminino', 'Perfume (EDP)', 'oriental', 'Intensa', ARRAY['noite','inverno']::text[], 124.9, '100 ml', 'Doce e sensual, com café, tuberosa e cacau.', NULL, NULL, false, 6, '{"ref":["Good Girl"],"notas":{"topo":["Amêndoa","Café"],"coracao":["Tuberosa","Jasmim"],"fundo":["Fava Tonka","Cacau","Baunilha"]},"acordes":[["Doce",100],["Floral branco",75],["Café",55],["Amadeirado",40]],"fixacao":[5,"Alta — 8h a 10h"],"projecao":[4,"Forte"],"concentracao":"20% de essência (Eau de Parfum)","rendimento":"aprox. 1.000 borrifadas"}'::jsonb),
  ('la-vie', 'Inspiração La Vie Est Belle', 'corporal', 'feminino', 'Perfume (EDP)', 'gourmand', 'Intensa', ARRAY['dia','noite','inverno']::text[], 124.9, '100 ml', 'Gourmand alegre de praliné e íris. Aconchego com personalidade.', NULL, NULL, false, 7, '{"ref":["La Vie Est Belle"],"notas":{"topo":["Pera","Groselha Negra"],"coracao":["Íris","Jasmim"],"fundo":["Praliné","Baunilha","Patchouli"]},"acordes":[["Doce / Praliné",100],["Frutado",65],["Floral",55],["Baunilha",80]],"fixacao":[5,"Alta — 8h a 10h"],"projecao":[4,"Forte"],"concentracao":"20% de essência (Eau de Parfum)","rendimento":"aprox. 1.000 borrifadas"}'::jsonb),
  ('bs-baunilha', 'Body Splash Baunilha & Âmbar', 'corporal', 'unissex', 'Body Splash', 'gourmand', 'Suave', ARRAY['relax','inverno','dia']::text[], 59.9, '200 ml', 'Base cremosa perfeita para camadas: use antes de um perfume amadeirado ou oriental.', NULL, NULL, false, 8, '{"notas":{"topo":["Bergamota"],"coracao":["Baunilha"],"fundo":["Âmbar","Almíscar"]},"acordes":[["Baunilha",100],["Âmbar",70],["Almíscar",50]],"fixacao":[2,"Suave — 2h a 4h"],"projecao":[2,"Rente à pele"],"concentracao":"Body splash (baixa concentração, ideal para reaplicar)","rendimento":"uso diário por ~2 meses"}'::jsonb),
  ('oleo-laranjeira', 'Óleo Corporal Flor de Laranjeira', 'corporal', 'feminino', 'Óleo Corporal Perfumado', 'floral', 'Suave', ARRAY['relax','verao']::text[], 69.9, '120 ml', 'Hidrata e perfuma. Aplicar no corpo ainda úmido após o banho.', NULL, NULL, false, 9, '{"notas":{"topo":["Neroli"],"coracao":["Flor de Laranjeira"],"fundo":["Almíscar Branco"]},"acordes":[["Floral branco",100],["Cítrico",45],["Almíscar",50]],"fixacao":[3,"Moderada — 4h a 6h"],"projecao":[1,"Bem rente à pele"],"concentracao":"Óleo perfumado com ação hidratante","rendimento":"aprox. 40 aplicações"}'::jsonb),
  ('difusor-bambu', 'Difusor de Varetas Bambu & Capim-Limão', 'casa', NULL, 'Difusor de Varetas', 'aromatico', 'Moderada', ARRAY['dia','verao']::text[], 89.9, '250 ml', 'Frescor verde e limpo que deixa a casa leve o dia inteiro.', 'assets/masc.jpg', '78% 70%', true, 10, '{"notasLista":["Bambu","Capim-Limão","Folhas Verdes"],"acordes":[["Verde",100],["Cítrico",75],["Fresco",60]],"ambiente":"Ideal para salas de estar e recepções — traz sensação de limpeza e sofisticação.","cobertura":"Aromatiza ambientes de até 25 m² e dura aproximadamente 45 a 60 dias.","instrucoes":["Vire as varetas a cada 3–5 dias (varetas de fibra) ou 2–3 dias (madeira).","Posicione longe de correntes de ar direto e do sol.","Mantenha fora do alcance de crianças e animais."]}'::jsonb),
  ('refil-difusor', 'Refil Difusor Bambu & Capim-Limão', 'casa', NULL, 'Refil', 'aromatico', 'Moderada', ARRAY['dia']::text[], 99.9, '500 ml', 'Refil sustentável e econômico: mantenha o frasco bonito e recompre só o líquido.', NULL, NULL, false, 11, '{"notasLista":["Bambu","Capim-Limão"],"acordes":[["Verde",100],["Cítrico",75]],"ambiente":"Reabasteça seu frasco de vidro e economize.","cobertura":"500 ml rende 2 recargas do difusor de 250 ml.","instrucoes":["Lave e seque o frasco antes de reabastecer.","Troque as varetas a cada recarga."]}'::jsonb),
  ('home-lavanda', 'Home Spray Lavanda & Alecrim', 'casa', NULL, 'Home Spray', 'aromatico', 'Suave', ARRAY['relax']::text[], 54.9, '250 ml', 'Calmante e herbal, para criar o ritual da noite.', NULL, NULL, false, 12, '{"notasLista":["Lavanda","Alecrim","Eucalipto"],"acordes":[["Lavanda",100],["Herbal",70],["Fresco",50]],"ambiente":"Perfeito para quartos — ajuda a desacelerar antes de dormir.","cobertura":"Aroma perceptível por 2 a 4 horas no ambiente.","instrucoes":["Borrife a cerca de 30 cm, no ar ou em cortinas.","Teste antes em tecidos delicados e couro.","Não borrife próximo a chamas."]}'::jsonb),
  ('agua-lencois', 'Água de Lençóis Algodão & Linho', 'casa', NULL, 'Água de Lençóis / Tecidos', 'floral', 'Suave', ARRAY['relax','dia']::text[], 49.9, '500 ml', 'O clássico cheiro de casa limpa e aconchegante.', NULL, NULL, false, 13, '{"notasLista":["Algodão","Linho","Almíscar Branco"],"acordes":[["Limpo",100],["Almíscar",65],["Floral leve",40]],"ambiente":"Roupas de cama, toalhas e cortinas com cheiro de roupa limpa.","cobertura":"Perfume nos tecidos por até 2 dias.","instrucoes":["Borrife a cerca de 30 cm do tecido.","Pode manchar seda e tecidos muito delicados: teste em área escondida.","Ótimo também ao passar roupa."]}'::jsonb),
  ('vela-sandalo', 'Vela Aromática Baunilha & Sândalo', 'casa', NULL, 'Vela Aromática', 'amadeirado', 'Moderada', ARRAY['relax','inverno','noite']::text[], 64.9, '180 g', 'Luz quente e aroma cremoso de madeira e baunilha.', NULL, NULL, false, 14, '{"notasLista":["Baunilha","Sândalo","Fava Tonka"],"acordes":[["Amadeirado cremoso",100],["Baunilha",80],["Doce",45]],"ambiente":"Salas e quartos — clima acolhedor para noites frias.","cobertura":"Aproximadamente 35 horas de queima total.","instrucoes":["Queime por no máximo 3 a 4 horas seguidas.","Apare o pavio para 0,5 cm antes de acender.","Nunca deixe acesa sem supervisão, perto de pets ou crianças."]}'::jsonb),
  ('essencia-bergamota', 'Essência Bergamota para Aromatizador Elétrico', 'casa', NULL, 'Aromatizador Elétrico / Essência', 'citrico', 'Moderada', ARRAY['dia','verao']::text[], 29.9, '10 ml', 'Cítrico luminoso para despertar o ambiente.', NULL, NULL, false, 15, '{"notasLista":["Bergamota","Laranja","Chá Branco"],"acordes":[["Cítrico",100],["Chá",50],["Fresco",45]],"ambiente":"Escritórios e home office — energia e foco.","cobertura":"Algumas gotas aromatizam até 20 m².","instrucoes":["Use 3 a 5 gotas na água do aromatizador.","Não aplique diretamente na pele.","Mantenha longe de crianças e animais."]}'::jsonb),
  ('pingente-cedro', 'Pingente Automotivo Madeira & Cedro', 'automotivo', NULL, 'Pingente de Madeira', 'amadeirado', 'Moderada', ARRAY['dia']::text[], 34.9, '10 ml', 'Madeira nobre e couro para deixar o carro com a sua assinatura.', NULL, NULL, true, 16, '{"notasLista":["Cedro","Vetiver","Couro"],"acordes":[["Amadeirado",100],["Couro",55],["Terroso",45]],"ambiente":"Carros e caminhonetes — sensação de carro novo e sofisticado.","cobertura":"Duração média de 30 dias.","instrucoes":["Pendure no retrovisor sem encostar no painel.","Reative com 2–3 gotas de refil quando enfraquecer.","Evite contato do líquido com plásticos e couro."]}'::jsonb),
  ('spray-carro', 'Spray Automotivo Couro & Bergamota', 'automotivo', NULL, 'Spray Automotivo', 'chipre', 'Moderada', ARRAY['dia']::text[], 39.9, '60 ml', 'Toque rápido de frescor sofisticado no carro.', NULL, NULL, false, 17, '{"notasLista":["Couro","Bergamota","Musgo"],"acordes":[["Couro",100],["Cítrico",60],["Musgo",45]],"ambiente":"Bancos de tecido, tapetes e carpetes.","cobertura":"Aroma por 2 a 3 dias em cada aplicação.","instrucoes":["Borrife a 30 cm em tapetes e bancos de tecido.","Não borrife em couro automotivo ou painel.","Ventile o carro após aplicar."]}'::jsonb),
  ('clipe-brisa', 'Clipe Saída de Ar Brisa Marinha', 'automotivo', NULL, 'Clipe de Saída de Ar', 'aromatico', 'Suave', ARRAY['verao','dia']::text[], 29.9, '8 ml', 'Brisa fresca e limpa a cada vez que o ar liga.', NULL, NULL, false, 18, '{"notasLista":["Notas Marinhas","Limão","Menta"],"acordes":[["Marinho",100],["Cítrico",60],["Fresco",55]],"ambiente":"Ideal para o calor: espalha com o ar-condicionado.","cobertura":"Duração média de 30 a 40 dias.","instrucoes":["Encaixe na aleta da saída de ar.","Ajuste a intensidade girando o regulador.","Não deixe exposto ao sol forte do painel."]}'::jsonb),
  ('kit-descoberta-frescor', 'Kit Descoberta Frescor para o Dia', 'kits', NULL, 'Discovery Set (5 × 2 ml)', 'aromatico', 'Moderada', ARRAY['dia','verao']::text[], 49.9, '5 × 2 ml', 'Zero risco: o valor do kit volta integralmente como cupom para o frasco grande.', NULL, NULL, false, 19, '{"notasLista":["Inspiração Sauvage","Inspiração Bleu","Inspiração Invictus","Inspiração Mademoiselle","Body Splash Baunilha"],"acordes":[["Fresco",100],["Cítrico",80],["Amadeirado",55]],"ambiente":"Experimente 5 fragrâncias antes de escolher o frasco grande.","cobertura":"Cada flaconete rende cerca de 20 borrifadas.","instrucoes":["Teste na pele, não só na fita: o perfume muda com o seu pH.","Avalie depois de 30 min (coração) e 3h (fundo).","O valor do kit volta como cashback na compra de um frasco de 100 ml."],"cashback":true}'::jsonb),
  ('kit-descoberta-noite', 'Kit Descoberta Noite & Sedução', 'kits', NULL, 'Discovery Set (5 × 2 ml)', 'oriental', 'Intensa', ARRAY['noite','inverno']::text[], 49.9, '5 × 2 ml', 'Descubra sua assinatura noturna sem medo de errar.', NULL, NULL, false, 20, '{"notasLista":["Inspiração Million","Inspiração Lady Million","Inspiração Good Girl","Inspiração La Vie Est Belle","Inspiração Bleu"],"acordes":[["Doce",100],["Especiado",75],["Floral",60]],"ambiente":"Os mais marcantes da casa para você comparar.","cobertura":"Cada flaconete rende cerca de 20 borrifadas.","instrucoes":["Teste um por dia, em pele limpa.","O valor do kit volta como cashback na compra de um frasco de 100 ml."],"cashback":true}'::jsonb),
  ('kit-casa', 'Kit Cheiro da Casa', 'kits', NULL, 'Kit Casa', 'aromatico', 'Moderada', ARRAY['dia','relax']::text[], 169.9, '3 itens', 'Difusor + água de lençóis + home spray em caixa presenteável.', NULL, NULL, false, 21, '{"notasLista":["Difusor Bambu 250 ml","Água de Lençóis 500 ml","Home Spray Lavanda 250 ml"],"acordes":[["Fresco",100],["Limpo",80],["Herbal",60]],"ambiente":"A casa inteira com uma identidade olfativa só.","cobertura":"Sala, quarto e roupa de cama.","instrucoes":["Siga as instruções de cada item na embalagem."]}'::jsonb),
  ('kit-viagem', 'Kit Viagem (3 × 10 ml)', 'kits', NULL, 'Kit Viagem', 'floral', 'Moderada', ARRAY['dia','noite']::text[], 79.9, '3 × 10 ml', 'Seus favoritos sempre com você.', NULL, NULL, false, 22, '{"notasLista":["Escolha 3 perfumes do catálogo em frascos de 10 ml"],"acordes":[["Do seu jeito",100]],"ambiente":"Cabe na bolsa e na bagagem de mão.","cobertura":"Cada 10 ml rende cerca de 100 borrifadas.","instrucoes":["Informe os 3 perfumes escolhidos ao finalizar no WhatsApp."]}'::jsonb),
  ('caixa-presente', 'Caixa Presenteável MyEssence', 'kits', NULL, 'Caixa Presenteável', 'gourmand', 'Moderada', ARRAY['noite','dia']::text[], 179.9, 'Kit', 'Presente pronto, com laço e cartão perfumado da marca.', NULL, NULL, false, 23, '{"notasLista":["1 perfume 100 ml à escolha","1 Body Splash","Cartão perfumado com mensagem"],"acordes":[["Presente",100]],"ambiente":"Aniversários, datas especiais e amigo secreto.","cobertura":"Entregue pronta para presentear.","instrucoes":["Informe o perfume e a mensagem do cartão ao finalizar."]}'::jsonb);

INSERT INTO referencias (nome, produto_id) VALUES
  ('Million', 'million'),
  ('1 Million', 'million'),
  ('One Million', 'million'),
  ('Sauvage', 'sauvage'),
  ('Bleu de Chanel', 'bleu'),
  ('Invictus', 'invictus'),
  ('Lady Million', 'lady-million'),
  ('Coco Mademoiselle', 'mademoiselle'),
  ('Good Girl', 'good-girl'),
  ('La Vie Est Belle', 'la-vie'),
  ('Acqua di Gio', 'invictus'),
  ('Paco Rabanne Phantom', 'sauvage'),
  ('Eros', 'million'),
  ('212 VIP', 'million'),
  ('Olympéa', 'lady-million'),
  ('Scandal', 'lady-million'),
  ('Idôle', 'la-vie'),
  ('Chance', 'mademoiselle'),
  ('Light Blue', 'invictus');

COMMIT;


-- ===================== CONSULTAS ÚTEIS =====================
-- Ver pedidos:                SELECT * FROM vw_pedidos;
-- Produtos mais vendidos:     SELECT * FROM vw_mais_vendidos;
-- Mudar preço:                UPDATE produtos SET preco = 139.90 WHERE id = 'million';
-- Marcar esgotado:            UPDATE produtos SET estoque = 0 WHERE id = 'million';
-- Tirar do site:              UPDATE produtos SET ativo = false WHERE id = 'million';
-- Avaliações para aprovar:    SELECT * FROM avaliacoes WHERE NOT aprovada;
-- Aprovar avaliação:          UPDATE avaliacoes SET aprovada = true WHERE id = 1;
-- Confirmar pedido:           UPDATE pedidos SET status = 'confirmado' WHERE codigo = 'ME-XXXXXX';
-- Criar cupom de cashback:    INSERT INTO cupons (codigo, valor, pedido_codigo, cliente, valido_ate)
--                             VALUES ('KIT-MARIA', 49.90, 'ME-XXXXXX', 'Maria', current_date + 60);
