// MyEssence Aromas — servidor Node.js sem dependências (Node 18+)
// Serve o site da pasta /public e a rota /api/chat, que conversa com a API do Claude.
// Configure no painel da Hostinger as variáveis ANTHROPIC_API_KEY e DATABASE_URL (Neon).

const http = require('http');
const fs = require('fs');
const path = require('path');
const db = require('./db');

const PORT = process.env.PORT || 3000;
const PUBLIC = path.join(__dirname, 'public');
const API_KEY = process.env.ANTHROPIC_API_KEY || '';
const MODEL = process.env.CLAUDE_MODEL || 'claude-haiku-5-5';

const TYPES = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css', '.js': 'text/javascript',
  '.json': 'application/json; charset=utf-8', '.png': 'image/png', '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.svg': 'image/svg+xml', '.ico': 'image/x-icon',
  '.mp4': 'video/mp4'
};

// ---------- prompt do assistente (montado a partir do catálogo) ----------
const brl = v => v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
function buildPrompt(D) {
  const L = D.loja, F = D.familias, O = D.ocasioes, C = D.categorias;
  const notes = p => p.notas ? [...p.notas.topo, ...p.notas.coracao, ...p.notas.fundo] : (p.notasLista || []);
  const cat = D.produtos.map(p =>
    `- ${p.nome} | ${C[p.cat]}${p.genero ? ' / ' + p.genero : ''} | ${p.tipo} | ${p.volume || ''} | ${brl(p.preco)} | família ${F[p.familia].nome} | intensidade ${p.intensidade} | ocasiões: ${p.ocasioes.map(o => O[o]).join(', ')} | notas: ${notes(p).join(', ')}` +
    (p.fixacao ? ` | fixação: ${p.fixacao[1]} | projeção: ${p.projecao[1]}` : '') +
    (p.cobertura ? ` | ${p.cobertura}` : '') +
    (p.instrucoes ? ` | uso: ${p.instrucoes.join(' ')}` : '') +
    (p.ref ? ` | referência olfativa: ${p.ref.join('/')}` : '')
  ).join('\n');
  return `Você é a assistente virtual da MyEssence Aromas, loja de perfumaria (corporal), aromatização de casa e automotiva. Responda sempre em português do Brasil, com simpatia e de forma curta (até 5 frases ou uma lista curta), como uma consultora de perfumaria.

Regras:
- Use apenas as informações abaixo. Não invente produtos, preços, prazos ou políticas. Se não souber, diga que a equipe responde no WhatsApp ${L.whatsappTexto}.
- Pedidos, frete, prazos e pagamento são finalizados no WhatsApp (o cliente pode usar o botão "Finalizar pedido no WhatsApp" na sacola).
- Os perfumes "Inspiração ..." são inspirados em perfumes famosos, usados só como referência olfativa; a loja não tem vínculo com essas marcas.
- Para escolher perfume, pergunte sobre gostos (ambiente, doce/fresco, intensidade, ocasião) e indique até 3 produtos do catálogo com o motivo.
- Assuntos fora da loja e de perfumaria: recuse com gentileza e volte ao tema.
- Não dê orientações médicas; em caso de alergia ou pele sensível, sugira teste em pequena área e procurar um médico.

Políticas da loja:
- Kits de descoberta (5 × 2 ml): o valor integral do kit volta como cupom de cashback na compra do frasco de 100 ml.
- Amostras grátis: ${L.reguaAmostras.map(r => `acima de ${brl(r.valor)} ganha ${r.brinde}`).join('; ')}.
- Refil de 500 ml para difusor com preço especial.
- Embalagem anti-quebra reforçada (tipo colmeia); opção "embalar para presente" com mensagem em cartão perfumado; todo pedido leva fitas olfativas com lançamentos.
- ${L.freteObs}
- Instagram: @${L.instagram}. WhatsApp: ${L.whatsappTexto}.
- Notas: saída = primeiros 15 min; coração = após 30 min; fundo = o que fica por horas. Fixação = quanto dura na pele; projeção = quanto se espalha.

Catálogo:
${cat}`;
}

// ---------- limite simples por IP (20 mensagens a cada 10 min) ----------
const hits = new Map();
function limited(ip, max = 20) {
  const now = Date.now(), win = 10 * 60 * 1000;
  const arr = (hits.get(ip) || []).filter(t => now - t < win);
  arr.push(now); hits.set(ip, arr);
  if (hits.size > 5000) hits.clear();
  return arr.length > max;
}
const ipOf = req => (req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').split(',')[0].trim();

function readBody(req, max = 20000) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', c => { data += c; if (data.length > max) { reject(new Error('too big')); req.destroy(); } });
    req.on('end', () => resolve(data));
    req.on('error', reject);
  });
}

function json(res, code, obj) {
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(obj));
}

async function handleChat(req, res) {
  if (limited('chat:' + ipOf(req))) return json(res, 429, { reply: 'Você enviou muitas mensagens. Aguarde alguns minutos ou fale com a gente no WhatsApp (11) 96391-4995.' });
  if (!API_KEY) return json(res, 503, { error: 'ANTHROPIC_API_KEY não configurada' });

  let body;
  try { body = JSON.parse(await readBody(req)); } catch { return json(res, 400, { error: 'JSON inválido' }); }

  // só aceita mensagens de texto curtas, alternando user/assistant, terminando em user
  let msgs = (Array.isArray(body.messages) ? body.messages : [])
    .filter(m => m && (m.role === 'user' || m.role === 'assistant') && typeof m.content === 'string')
    .map(m => ({ role: m.role, content: m.content.slice(0, 1500) }))
    .slice(-12);
  while (msgs.length && msgs[0].role !== 'user') msgs.shift();
  if (!msgs.length || msgs[msgs.length - 1].role !== 'user') return json(res, 400, { error: 'mensagem vazia' });

  try {
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'x-api-key': API_KEY, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
      body: JSON.stringify({ model: MODEL, max_tokens: 600, system: buildPrompt(await db.getCatalog()), messages: msgs }),
      signal: AbortSignal.timeout(60000)
    });
    const j = await r.json();
    if (!r.ok) { console.error('Claude API', r.status, j && j.error); return json(res, 502, { error: 'falha na IA' }); }
    const reply = (j.content || []).filter(b => b.type === 'text').map(b => b.text).join('\n').trim();
    return json(res, 200, { reply });
  } catch (e) {
    console.error('Claude API erro', e.message);
    return json(res, 502, { error: 'falha na IA' });
  }
}

// ---------- pedidos (salvos na Neon antes de abrir o WhatsApp) ----------
async function handlePedido(req, res) {
  if (!db.ativo()) return json(res, 503, { error: 'banco não configurado' });
  if (limited('ped:' + ipOf(req), 15)) return json(res, 429, { error: 'muitas tentativas' });
  let b;
  try { b = JSON.parse(await readBody(req)); } catch { return json(res, 400, { error: 'JSON inválido' }); }
  const codigo = String(b.codigo || '');
  if (!/^ME-[A-Z0-9]{6}$/.test(codigo)) return json(res, 400, { error: 'código inválido' });
  const itens = (Array.isArray(b.itens) ? b.itens : []).slice(0, 50)
    .map(i => ({ id: String(i && i.id || '').slice(0, 60), qtd: Math.min(99, Math.max(1, parseInt(i && i.qtd, 10) || 1)) }))
    .filter(i => /^[a-z0-9-]+$/.test(i.id));
  if (!itens.length) return json(res, 400, { error: 'sem itens' });
  try {
    const r = await db.salvarPedido({ codigo, itens, presente: !!b.presente, mensagem: String(b.mensagem || '').slice(0, 300) });
    return json(res, 200, r);
  } catch (e) { console.error('pedido:', e.message); return json(res, 500, { error: 'não foi possível salvar' }); }
}

// ---------- avaliações ----------
async function handleAvaliacoes(req, res) {
  if (!db.ativo()) return json(res, 503, { error: 'banco não configurado' });
  if (req.method === 'GET') {
    const id = new URL(req.url, 'http://x').searchParams.get('produto') || '';
    if (!/^[a-z0-9-]{1,60}$/.test(id)) return json(res, 400, { error: 'produto inválido' });
    try { return json(res, 200, { avaliacoes: await db.listarAvaliacoes(id) }); }
    catch (e) { console.error('avaliações:', e.message); return json(res, 500, { avaliacoes: [] }); }
  }
  if (limited('av:' + ipOf(req), 5)) return json(res, 429, { error: 'muitas avaliações' });
  let b;
  try { b = JSON.parse(await readBody(req, 5000)); } catch { return json(res, 400, { error: 'JSON inválido' }); }
  const a = {
    produto: String(b.produto || ''), nome: String(b.nome || '').trim().slice(0, 60),
    nota: parseInt(b.nota, 10),
    fixacao: ['Fraca', 'Boa', 'Excelente'].includes(b.fixacao) ? b.fixacao : null,
    fiel: typeof b.fiel === 'boolean' ? b.fiel : null,
    uso: String(b.uso || '').trim().slice(0, 80) || null,
    comentario: String(b.comentario || '').trim().slice(0, 600) || null
  };
  if (!/^[a-z0-9-]{1,60}$/.test(a.produto) || !a.nome || !(a.nota >= 1 && a.nota <= 5)) return json(res, 400, { error: 'dados incompletos' });
  try { await db.salvarAvaliacao(a); return json(res, 200, { ok: true }); }
  catch (e) { console.error('avaliação:', e.message); return json(res, 500, { error: 'não foi possível salvar' }); }
}

function serveStatic(req, res) {
  let urlPath = decodeURIComponent(new URL(req.url, 'http://x').pathname);
  if (urlPath.endsWith('/')) urlPath += 'index.html';
  const file = path.normalize(path.join(PUBLIC, urlPath));
  if (!file.startsWith(PUBLIC)) { res.writeHead(403); return res.end(); }
  fs.readFile(file, (err, data) => {
    if (err) {
      // rotas desconhecidas voltam para a página inicial
      return fs.readFile(path.join(PUBLIC, 'index.html'), (e2, html) => {
        if (e2) { res.writeHead(404); return res.end('Não encontrado'); }
        res.writeHead(200, { 'Content-Type': TYPES['.html'] }); res.end(html);
      });
    }
    const ext = path.extname(file).toLowerCase();
    res.writeHead(200, {
      'Content-Type': TYPES[ext] || 'application/octet-stream',
      'Cache-Control': ext === '.html' || ext === '.json' ? 'no-cache' : 'public, max-age=604800'
    });
    res.end(data);
  });
}

http.createServer((req, res) => {
  if (req.url.startsWith('/api/chat')) {
    if (req.method !== 'POST') return json(res, 405, { error: 'use POST' });
    return handleChat(req, res);
  }
  if (req.url.startsWith('/api/pedidos')) {
    if (req.method !== 'POST') return json(res, 405, { error: 'use POST' });
    return handlePedido(req, res);
  }
  if (req.url.startsWith('/api/avaliacoes')) {
    if (req.method !== 'POST' && req.method !== 'GET') return json(res, 405, { error: 'método inválido' });
    return handleAvaliacoes(req, res);
  }
  if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); return res.end(); }
  if (req.url.split('?')[0] === '/catalog.json') {
    return db.getCatalog().then(d => {
      res.writeHead(200, { 'Content-Type': TYPES['.json'], 'Cache-Control': 'no-cache' });
      res.end(JSON.stringify(d));
    }).catch(() => serveStatic(req, res));
  }
  serveStatic(req, res);
}).listen(PORT, () => console.log(`MyEssence rodando na porta ${PORT} — banco Neon: ${db.ativo() ? 'conectado' : 'desligado (usando catalog.json)'}`));
